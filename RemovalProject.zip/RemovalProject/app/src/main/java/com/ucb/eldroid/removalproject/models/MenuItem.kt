package com.ucb.eldroid.removalproject.models

data class MenuItem(
    val id: String,
    val foodName: String,
    val price: Double
)